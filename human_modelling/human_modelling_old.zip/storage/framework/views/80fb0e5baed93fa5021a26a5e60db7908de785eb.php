

<?php $__env->startSection('title', 'List Data Ticket'); ?>

<?php $__env->startSection('plugin_css'); ?>
<!-- Plugins css start-->
<link rel="stylesheet" type="text/css" href="<?php echo e(url('/assets/css/date-picker.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('/assets/css/sweetalert2.css')); ?>">
<!-- Plugins css Ends-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- page-wrapper Start       -->
<div class="page-wrapper compact-wrapper" id="pageWrapper">
    <!-- Page Header Start-->
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page Header End-->
    <!-- Page Body Start-->
    <div class="page-body-wrapper sidebar-icon">
        <!-- Page Sidebar Start-->
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Page Sidebar End-->
        <div class="page-body">
            <!-- Container-fluid starts-->
            <div class="container-fluid">
                <div class="row">
                    <div class="container-fluid">
                        <div class="page-header">
                            <div class="row">
                                <div class="col-sm-6">
                                    <h3>List Data Tickets</h3>
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.processingData.index')); ?>">Home</a></li>
                                        <li class="breadcrumb-item">Data</li>
                                        <li class="breadcrumb-item active">List Data Tickets</li>
                                    </ol>
                                </div>
                                <div class="col-sm-6">
                                    <!-- Bookmark Start-->
                                    <div class="bookmark">
                                        <ul>
                                            <li><a href="javascript:void(0)" data-container="body" data-bs-toggle="popover" data-placement="top" title="" data-original-title="Tables"><i data-feather="inbox"></i></a></li>
                                            <li><a href="javascript:void(0)" data-container="body" data-bs-toggle="popover" data-placement="top" title="" data-original-title="Chat"><i data-feather="message-square"></i></a></li>
                                            <li><a href="javascript:void(0)" data-container="body" data-bs-toggle="popover" data-placement="top" title="" data-original-title="Icons"><i data-feather="command"></i></a></li>
                                            <li><a href="javascript:void(0)" data-container="body" data-bs-toggle="popover" data-placement="top" title="" data-original-title="Learning"><i data-feather="layers"></i></a></li>
                                            <li><a href="javascript:void(0)"><i class="bookmark-search" data-feather="star"></i></a>
                                            <form class="form-inline search-form">
                                                <div class="form-group form-control-search">
                                                    <input type="text" placeholder="Search..">
                                                </div>
                                            </form>
                                            </li>
                                        </ul>
                                    </div>
                                    <!-- Bookmark Ends-->
                                </div>
                            </div>
                        </div>
                        <!-- Container-fluid starts-->
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xl-12 xl-60 box-col-8">
                                    <?php if($tickets->count() == 0): ?> <center>You have no ticket</center> <?php endif; ?>
                                    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                                        <div class="card">
                                            <div class="job-search">
                                                <div class="card-body">
                                                    <div class="media">
                                                        <div class="media-body">
                                                            <h6 class="f-w-600">
                                                                <a href="job-details.html"><?php echo e($ticket->ssp_ticket_job_title); ?></a>
                                                                <a href="#"><button type="button" class="btn btn-outline-danger pull-right" style="width: 37px; padding-top: 2px; padding-left: 0px; padding-right: 0px; padding-bottom: 2px;"><i class="fa fa-trash" style="font-size:20px;"></i></button></a>
                                                                <a href="#"><button type="button" class="btn btn-outline-primary pull-right" style="width: 37px; padding-top: 2px; padding-left: 0px; padding-right: 0px; padding-bottom: 2px; margin-right:5px;"><i class="fa fa-edit" style="font-size:20px;"></i></button></a>
                                                            </h6>
                                                            <i class="fa fa-map-marker"></i><p><?php echo e($ticket->ssp_ticket_job_location); ?></p>
                                                            
                                                        </div>
                                                    </div>
                                                    <p>
                                                    We are looking for an experienced and viho designer and/or frontend engineer with expertise in accessibility to join our team ,
                                                    3+ years of experience working in as a Frontend Engineer or comparable role. You won’t be a team of one though — you’ll be collaborating closely with other...
                                                    </p>
                                                    <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#importCSVModal" ></i>Upload CSV Data</button>
                                                    <a href="<?php echo e(route('admin.dataTicket.index', $ticket->id)); ?>"><button type="button" class="btn btn-outline-primary"></i>Show</button></a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="job-pagination">
                                    <nav aria-label="Page navigation example">
                                        <ul class="pagination pagination-primary">
                                            <li class="page-item disabled"><a class="page-link" href="javascript:void(0)">Previous</a></li>
                                            <li class="page-item active"><a class="page-link" href="javascript:void(0)">1</a></li>
                                            <li class="page-item"><a class="page-link" href="javascript:void(0)">2</a></li>
                                            <li class="page-item"><a class="page-link" href="javascript:void(0)">3</a></li>
                                            <li class="page-item"><a class="page-link" href="javascript:void(0)">Next</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button class="float btn btn-add btn btn-outline-primary mt-1 mb-1" data-bs-toggle="modal" data-bs-target="#createTicketModal" data-tooltip="tooltip" data-placement="left" title="" data-original-title="">
                        <span class="btn-inner--icon"><i class="icon-plus" style="font-weight: bold;font-size: 20px;"></i></span>
                    </button>

                    
                </div>
            </div>
            
            <!-- Container-fluid Ends-->
        </div>
    </div>
    <!-- footer start-->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</div> 

<!-- Modal Create Ticket-->
<div class="modal fade" id="createTicketModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Create Ticket</h3>
                <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form class="theme-form" id="dataCreateTicket" enctype="multipart/form-data" action="" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">  
                            <div class="form-group row">
                                <label class="col-xl-2 col-sm-3 col-form-label">Job Title</label>
                                <div class="col-xl-10 col-sm-9">
                                    <input type="text" class="form-control" id="nama_project" name="nama_project" placeholder="Title..." >
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-xl-2 col-sm-3 col-form-label">Job Location</label>
                                <div class="col-xl-10 col-sm-9">
                                <input type="text" class="form-control" id="nama_project" name="nama_project" placeholder="Location..." >
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-xl-2 col-sm-3 col-form-label">Analyst</label>
                                <div class="col-xl-10 col-sm-9">
                                <input type="text" class="form-control" id="nama_project" name="nama_project" placeholder="Analyst..." >
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-xl-2 col-sm-3 col-form-label">Job Date</label>
                                <div class="col-xl-10 col-sm-9">
                                    <input class="form-control digits" id="minMaxExample" type="text">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-xl-2 col-sm-3 col-form-label">Job Comments</label>
                                <div class="col-xl-10 col-sm-9">
                                    <textarea class="form-control" id="exampleFormControlTextarea4" rows="3"></textarea>
                                </div>
                            </div>
                            <!-- <div class="form-group form-alert">
                                <label class="form-label" >Upload OAuth</label>
                                <input type="file" value="" class="form-control input-md" name="oauth" id="oauth" accept="application/JSON">
                                <button type="button" class="form-control mt-1 btn btn-outline-info" onclick="window.open('https://console.developers.google.com', '_blank'); return false;">Get OAuth</button>
                            </div>  -->
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <!-- 
                     -->
                    <button type="button" class="btn btn-blue-gradient" data-dismiss="modal">Close</button>
                    <button type="button" onclick="createTicket()" class="btn btn-green-gradient">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Create Ticket-->
<div class="modal fade" id="importCSVModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Import CSV</h3>
                <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form class="theme-form" id="dataImportCSV" enctype="multipart/form-data" action="" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group row">
                                <label class="col-xl-3 col-sm-4 col-form-label">CSV file to Import</label>
                                <div class="col-xl-9 col-sm-8">
                                    <input type="file" value="" class="form-control input-md" name="csvFile" id="csv-file" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-blue-gradient" data-dismiss="modal">Close</button>
                    <button type="button" onclick="parseCSVData()" class="btn btn-green-gradient">Process CSV Data</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin_js'); ?>
<!-- Plugins JS start-->
<script src="<?php echo e(url('/assets/js/datepicker/date-picker/datepicker.js')); ?>"></script>
<script src="<?php echo e(url('/assets/js/datepicker/date-picker/datepicker.en.js')); ?>"></script>
<script src="<?php echo e(url('/assets/js/sweet-alert/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(url('/assets/js/tooltip-init.js')); ?>"></script>
<!-- Plugins JS Ends-->

<script>
    $(document).ready(function(){
        $('#minMaxExample').datepicker({
            language: 'en',
            dateFormat: 'dd-mm-yyyy',
            minDate: new Date() // Now can select only dates, which goes after today
        });
    });

    function createTicket(){
        swal.fire({
            title: "Create Ticket",
            text: "Add new Ticket data? ",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: "Save",
            showLoaderOnConfirm: true,
            preConfirm: (login) => {  
                var form = $("#dataCreateTicket").get(0)
                return $.ajax({
                    type: "POST", 
                    url: "formProjects/create/",
                    processData: false,
                    contentType: false,
                    cache: false,
                    data: new FormData(form), 
                    success: function(data) {
                    var request = 'success';
                    },
                    error: function(xhr, status, error){
                        swal.fire({title:"Add Data Ticket Error!", text: xhr.responseText, icon:"error"});
                        console.log(xhr)
                    }
                });
            }                       
        }).then((result) => {
        console.log("sadsa ", result.value)
            if(result.value){
            swal.fire({title:"New Ticket Data Added", text:"Successfuly add new Ticket data!", icon:"success"})
            .then(function(){ 
                window.location.reload();
            });
            }
        })
    }

    function parseCSVData(){
        swal.fire({
            title: "Import CSV Data",
            text: "Add new Ticket data? ",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: "Process CSV Data",
            showLoaderOnConfirm: true,
            preConfirm: (login) => {  
                var form = $("#dataImportCSV").get(0)
                return $.ajax({
                    type: "POST", 
                    url: "<?php echo e(route('admin.processingData.storeDataCSV')); ?>",
                    processData: false,
                    contentType: false,
                    cache: false,
                    data: new FormData(form), 
                    success: function(data) {
                    var request = 'success';
                    },
                    error: function(xhr, status, error){
                        swal.fire({title:"Add Data Ticket Error!", text: xhr.responseText, icon:"error"});
                        console.log(xhr)
                    }
                });
            }                       
        }).then((result) => {
        console.log("sadsa ", result.value)
            if(result.value){
            swal.fire({title:"New Ticket Data Added", text:"Successfuly add new Ticket data!", icon:"success"})
            .then(function(){ 
                window.location.reload(true);
            });
            }
        })
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\human_modelling\resources\views/admin/viewData/ticketsList.blade.php ENDPATH**/ ?>