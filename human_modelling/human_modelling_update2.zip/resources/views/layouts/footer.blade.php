@yield('footer')
<footer class="footer">
    <div class="container-fluid">
    <div class="row">
        <div class="col-md-6 footer-copyright">
        <!-- <p class="mb-0">Copyright 2022 ©.</p> -->
        </div>
    </div>
    </div>
</footer>